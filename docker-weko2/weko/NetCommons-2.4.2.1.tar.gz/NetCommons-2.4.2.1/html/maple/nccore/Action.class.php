<?php
class Action
{
}
?>
